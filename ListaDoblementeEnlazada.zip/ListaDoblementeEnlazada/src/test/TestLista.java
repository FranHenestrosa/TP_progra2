package test;

import interfaces.ILista;
import modelo.Lista;
import modelo.Persona;

public class TestLista {

	public static void main(String[] args) {
        ILista lista = new Lista();
        
        Persona p = new Persona("Juan");
        Persona p1 = new Persona("Carlos");
        Persona p2 = new Persona("Bauti");
        Persona p3 = new Persona("Lucas");
        p.agregarVehiculo("ABC123");
        p.agregarVehiculo("XYZ789");
        p1.agregarVehiculo("ELS385");
        p1.agregarVehiculo("KSB295");
        p1.agregarVehiculo("BNM054");
        p2.agregarVehiculo("LCE237");
        p3.agregarVehiculo("SHK928");
        p3.agregarVehiculo("SEY653");
        p.mostrarVehiculos();
        p1.mostrarVehiculos();
        p2.mostrarVehiculos();
        p3.mostrarVehiculos();
    }

}
