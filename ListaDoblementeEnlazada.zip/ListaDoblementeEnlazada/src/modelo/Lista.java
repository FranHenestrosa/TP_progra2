package modelo;

import interfaces.ILista;
import interfaces.INodo;

public class Lista implements ILista {
    private INodo primero;

    public Lista() {
        this.primero = null;
    }

    @Override
    public boolean esVacia() {
        return primero == null;
    }

    @Override
    public void insertarPrimero(int dato) {
        INodo nuevo = new Nodo(dato);
        if (primero != null) {
            primero.setAnterior(nuevo);
        }
        primero = nuevo;
    }

    @Override
    public void insertarUltimo(int dato) {
        INodo nuevo = new Nodo(dato);
        if (esVacia()) {
            primero = nuevo;
        } else {
            INodo actual = primero;
            while (actual.getSiguiente() != null) {
                actual = actual.getSiguiente();
            }
            actual.setSiguiente(nuevo);
            nuevo.setAnterior(actual);
        }
    }

    @Override
    public void insertarPosicion(int dato, int posicion) {
        if (posicion == 0) {
            insertarPrimero(dato);
            return;
        }

        INodo actual = primero;
        int contador = 0;

        while (actual != null && contador < posicion - 1) {
            actual = actual.getSiguiente();
            contador++;
        }

        if (actual == null) {
            throw new IndexOutOfBoundsException("Posición fuera de rango");
        }

        INodo nuevo = new Nodo(dato);
        INodo siguiente = actual.getSiguiente();

        nuevo.setSiguiente(siguiente);
        nuevo.setAnterior(actual);
        actual.setSiguiente(nuevo);
        
        if (siguiente != null) {
            siguiente.setAnterior(nuevo);
        }
    }

    @Override
    public void eliminarPrimero() {
    	if (!esVacia()) {
            primero = primero.getSiguiente();
            if (primero != null) {
                primero.setAnterior(null);
            }
        }
    }

    @Override
    public void eliminarUltimo() {
        if (esVacia()) return;

        if (primero.getSiguiente() == null) {
            primero = null;
            return;
        }

        INodo actual = primero;
        while (actual.getSiguiente() != null) {
            actual = actual.getSiguiente();
        }
        
        INodo anterior = actual.getAnterior();
        if (anterior != null) {
            anterior.setSiguiente(null);
        }
    }

    @Override
    public void eliminarPosicion(int posicion) {
        if (esVacia()) return;

        if (posicion == 0) {
            eliminarPrimero();
            return;
        }

        INodo actual = primero;
        int contador = 0;

        while (actual != null && contador < posicion) {
            actual = actual.getSiguiente();
            contador++;
        }

        if (actual == null) {
            throw new IndexOutOfBoundsException("Posición fuera de rango");
        }

        INodo anterior = actual.getAnterior();
        INodo siguiente = actual.getSiguiente();
        
        if (anterior != null) {
            anterior.setSiguiente(siguiente);
        }

        if (siguiente != null) {
            siguiente.setAnterior(anterior);
        }
    }

    @Override
    public int obtenerPrimero() {
        if (esVacia()) throw new IllegalStateException("Lista vacía");
        return primero.getDato();
    }

    @Override
    public int obtenerUltimo() {
        if (esVacia()) throw new IllegalStateException("Lista vacía");

        INodo actual = primero;
        while (actual.getSiguiente() != null) {
            actual = actual.getSiguiente();
        }
        return actual.getDato();
    }

    @Override
    public int obtenerPosicion(int posicion) {
        INodo actual = primero;
        int contador = 0;

        while (actual != null && contador < posicion) {
            actual = actual.getSiguiente();
            contador++;
        }

        if (actual == null) throw new IndexOutOfBoundsException("Posición fuera de rango");

        return actual.getDato();
    }

    @Override
    public int cantidadElementos() {
        int contador = 0;
        INodo actual = primero;

        while (actual != null) {
            contador++;
            actual = actual.getSiguiente();
        }

        return contador;
    }

    @Override
    public int buscarSecuencial(int dato) {
        INodo actual = primero;
        int posicion = 0;

        while (actual != null) {
            if (actual.getDato() == dato) {
                return posicion;
            }
            actual = actual.getSiguiente();
            posicion++;
        }

        return -1; // no encontrado
    }

    @Override
    public void ordenarLista() {
        if (esVacia() || primero.getSiguiente() == null) return;

        boolean cambiado;
        do {
            cambiado = false;
            INodo actual = primero;
            while (actual.getSiguiente() != null) {
                if (actual.getDato() > actual.getSiguiente().getDato()) {
                    int temp = actual.getDato();
                    actual.setDato(actual.getSiguiente().getDato());
                    actual.getSiguiente().setDato(temp);
                    cambiado = true;
                }
                actual = actual.getSiguiente();
            }
        } while (cambiado);
    }

    @Override
    public void mostrarLista() {
        INodo actual = primero;
        while (actual != null) {
        	actual.imprimir();
        	System.out.print(" <-> ");
            actual = actual.getSiguiente();
        }
        System.out.println("null");
    }
}