package modelo;

import interfaces.ILista;

public class Persona {
    private String nombre;
    private ILista vehiculos;

    public Persona(String nombre) {
        this.nombre = nombre;
        this.vehiculos = new Lista(); // lista doblemente enlazada
    }

    public void agregarVehiculo(String patente) {
        // Para simplificar, solo agregamos el hashCode del vehículo como dato
        vehiculos.insertarUltimo(patente.hashCode());
    }

    public void mostrarVehiculos() {
        System.out.print("Vehículos de " + nombre + ": ");
        vehiculos.mostrarLista();
    }
}

