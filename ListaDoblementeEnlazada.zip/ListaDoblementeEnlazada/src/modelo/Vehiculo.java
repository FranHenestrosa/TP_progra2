package modelo;

public class Vehiculo {
    private String patente;

    public Vehiculo(String patente) {
        this.patente = patente;
    }

    public String getPatente() {
        return patente;
    }

    @Override
    public String toString() {
        return patente;
    }
}
